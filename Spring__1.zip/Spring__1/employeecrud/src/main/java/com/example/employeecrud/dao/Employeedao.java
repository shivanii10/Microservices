package com.example.employeecrud.dao;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.example.employeecrud.model.Employee;

@Repository
@Transactional
public interface Employeedao extends JpaRepository<Employee,Integer> {

}
